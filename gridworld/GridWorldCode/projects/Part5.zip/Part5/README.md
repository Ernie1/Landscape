## 文件结构
```
.
├── 1
│   ├── OccupantInCol.java
│   └── SparseBoundedGrid.java
├── 2
│   └── SparseBoundedGrid2.java
├── 3
│   └── UnboundedGrid2.java
└── SparseGridRunner.java
```

## 运行方法
直接运行SparseGridRunner，通过World->set grid切换grid类型。
![这里写图片描述](https://img-blog.csdn.net/20180421112854382?watermark/2/text/aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L1pfSl9RXw==/font/5a6L5L2T/fontsize/400/fill/I0JBQkFCMA==/dissolve/70)